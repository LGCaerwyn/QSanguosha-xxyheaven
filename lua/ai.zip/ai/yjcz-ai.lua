sgs.ai_skill_discard.yjcz_xiaochen = function(self, discard_num, min_num, optional, include_equip)
	return self:askForDiscard("dummyreason", 1, 1, false, true)
end